﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Prologue
{
    //General screen information/ functions used by every Class

    public static class Screen
    {
        static public float ScreenWidth { get; set; }
        static public float ScreenHeight { get; set; }

        static public int MinGridX = 16;
        static public int MinGridY = 9;

        static public int ChunckSize = 16;

        static public float GridSize { get; set; }

        static public float CameraX { get; set; }
        static public float CameraY { get; set; }

        static public Tuple<float, float> ScreenCords(int x, int y)
        {
            //Console.WriteLine(GridSize);
            //Console.WriteLine(x * GridSize + " " + y * GridSize);
            return Tuple.Create(x * GridSize, y * GridSize);
        }

        static public int CurrentChunck(int gridy)
        {
            int _chunck = (int)Math.Ceiling((double)(gridy / ChunckSize)); 
            return _chunck;
        }

        static public Tuple<int, int> GridCords(float x, float y)
        {
            //Console.WriteLine( x+ " " + y);
            return Tuple.Create((int)Math.Floor(x / GridSize), (int)Math.Floor(y / GridSize));
        }

        static public void CameraMovement(float PlayerX, float PlayerY)
        {
            CameraX = PlayerX - (ScreenWidth / 2);
            CameraY = PlayerY - (ScreenHeight / 2);

            //Console.WriteLine(CameraX + " " + PlayerX + "   ---   " + CameraY + " " + PlayerY);
        }

    }

    public static class Utility
    {
        public static List<Tuple<int,int>> GeneratePath(Tuple<int,int> StartPosition, Tuple<int,int> Goal)
        {
            List<Tuple<int, int>> Path = new List<Tuple<int, int>>();

            List<Tiles> Ground = new List<Tiles>(Map.Tilelist.FindAll(x => x.Solid == false && x.Y.IsBetween(StartPosition.Item2, Goal.Item2)));
            
            foreach(var x in Ground)
            {
                //Console.WriteLine("The X Cord: " + x.X + " -- The Y Cord: " + x.Y );
                PathFinderTile.PathTiles.Add(new PathFinderTile(Tuple.Create(x.X, x.Y)));
            }

            if (!PathFinderTile.PathTiles.Any())
            {
                Path.Add(StartPosition);
                return Path;
            }

            PathFinderTile Tile = PathFinderTile.PathTiles.Find(x => x.Cords == StartPosition);
            if (Tile == null)
            {
                Tile = PathFinderTile.PathTiles.Find(x => x.Cords.Item2 == StartPosition.Item2);
            }
            if (Tile == null)
            {
                Tile = PathFinderTile.PathTiles[0];
            }
            Tile.On = true;
            Tile.Beginnin = true;


            int Itteration = 0;
            while (!PathFinderTile.PathTiles.All(x => x.On == true))
            {
                if (Itteration > 15)
                {
                    break;
                }

                PathFinderTile.CheckForPath();
                Itteration++;
            }

            PathFinderTile GoalTile = PathFinderTile.PathTiles.Find(x => x.Cords.Equals(Goal));
            Path.Add(GoalTile.Cords);

            PathFinderTile PathTile = PathFinderTile.PathTiles.Find(x => x.Cords.Equals(GoalTile.Carrier));
            Path.Add(PathTile.Cords);

            Itteration = 0;

            while(PathTile.Beginnin != true)
            {
                if (PathTile.Carrier == null || Itteration > 15)
                {
                    break;
                }

                PathFinderTile PathTile1 = PathFinderTile.PathTiles.Find(x => x.Cords.Equals(PathTile.Carrier));
                PathTile = PathTile1;
                Path.Add(PathTile.Cords);
                Itteration++;
            }

            foreach (var _x in Path)
            {
                Console.WriteLine(_x);
            }

            Console.WriteLine(Itteration);

         

            
            return Path;
        }

        public static bool IsBetween<T>(this T item, T start, T end)
        {
            return Comparer<T>.Default.Compare(item, start) >= 0
                && Comparer<T>.Default.Compare(item, end) <= 0;
        }

    }

    class PathFinderTile
    {
        public Tuple<int,int> Cords { get; set; }
        public Tuple<int,int> North { get; set; }
        public Tuple<int, int> East { get; set; }
        public Tuple<int, int> South { get; set; }
        public Tuple<int, int> West { get; set; }

        public bool Beginnin { get; set; }
        public bool On { get; set; }
        public Tuple<int,int> Carrier { get; set; }

        public static List<PathFinderTile> PathTiles = new List<PathFinderTile>();

        public PathFinderTile(Tuple<int, int> Cords)
        {
            this.Cords = Cords;
            this.On = false;
            this.Beginnin = false;

            this.Carrier = null;

            this.North = Tuple.Create(Cords.Item1, Cords.Item2 - 1);
            this.East = Tuple.Create(Cords.Item1 + 1, Cords.Item2);
            this.South = Tuple.Create(Cords.Item1, Cords.Item2 + 1);
            this.West = Tuple.Create(Cords.Item1 + 1, Cords.Item2);
        }

        public static void CheckForPath()
        {
            foreach (PathFinderTile _Tile in PathTiles)
            {
                if (_Tile.On == true)
                {
                    List<PathFinderTile> _TempList = new List<PathFinderTile>(PathTiles.FindAll(x => x.Cords.Equals(_Tile.South) || x.Cords.Equals( _Tile.North) || x.Cords.Equals(_Tile.East) || x.Cords.Equals(_Tile.West)));

                    foreach (PathFinderTile x in _TempList)
                    {
                        if (x.On != true)
                        {
                            
                            x.On = true;
                            x.Carrier = _Tile.Cords;
                        }
                    }
                }
            }
        }


    }
}
